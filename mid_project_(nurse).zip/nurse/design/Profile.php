<!DOCTYPE HTML>
<html>
	<head>
		
		<title>Nurse Profile</title>
	</head>
	<body>
		<div>
			<table border="1">	
					</tr>
						<td colspan ="2" width ="100%" height="50px" align="center"><h1>Welcome to Nurse Profile</h1></td>
					</tr>
					</tr>
						<td>
							<ul>
								<li><a href="EditProfile.php"><h3>Edit Profile</h3></a></li>
								<li><a href="ChangePassword.php"><h3>Change Password</h3></a></li>
								<li><a href="../valid/Logout.php"><h3>Logout</h3></a></li>
							</ul>
						</td>
						<td width ="1200px" height ="700px">
							<fieldset>
								<legend>Profile</legend>	
									<table align="center">
										
										<tr>
											<td></td>
											<td></td>
											<td></td>
											<td align="right"><img width="200px" src="t.jpg" alt="Profile picture" /></td>
											<td><input type="file" value="choose file"><br><br>
											<input type="button" value="Delete"></td>
										</tr>
										<tr>
		
											<td>User Id:</td>
											<td><?php
												echo "17-34631-2"		
											     ?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Name:</td>
											<td><?php
											echo "Nishat Tasnim";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Email:</td>
											<td><?php echo "nishat@gmail.com";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Gender:</td>
											<td><?php echo "Female"  ?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Address:</td>
											<td><?php echo "Basundhara R\A";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Joining Date:</td>
											<td><?php echo "2020-11-14";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Blood Group:</td>
											<td><?php echo "0+";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Phone:</td>
											<td><?php echo "01849975295";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											<td>Date Of Birth:</td>
											<td><?php echo "24-11-1996";?></td>
											<td></td>
											<td></td>
										</tr>
										<tr>
											<td colspan="3"><hr></td>
										</tr>
										<tr>
											
											<td></td>
											<td></td>
											<td></td>
										</tr>											
									</table>	
							</fieldset>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center"><h4>Copyright from @glaxoserfr4.com<h4></td>
					</tr>
			</table>
			</div>
					
			
	</body>
</html>