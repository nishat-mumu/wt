<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<h2>Welcome </h2>
<body>
<form>
<a href="Profile.php"><input type="button" value="Profile"></a>
<br><br>
<a href="Salaryhistory.php" ><input type="button" value="salary history"></a>
<br><br>
<a href="ApplyChange.php"><input type="button" value="Apply for change"></a>
<br><br>
<a href="Request.php"><input type="button" value="Request for increase salary"></a>
<br><br>
<a href="ApplyLeave.php"><input type="button" value="Apply for leave"></a>
<br><br>
<a href="AskingGro.php"><input type="button" value="Asking Grocery"></a>
<br><br>
<a href="../valid/Logout.php"><input type="button" value="Logout"></a>
</form>
</body>
</html>