<html>
<head></head>
<title>Apply Change</title>
<body>

<center>
<form method="post" action="ApplySubmit.php">

<table>
	<tr>
		<td>Request	to Admin:</td>
		<td><textarea rows="10" cols="30"></textarea></td>
		<td><input type="submit" value ="Send"</td>
	</tr>
</table>
	
</form>
</center>
</body>
</html>